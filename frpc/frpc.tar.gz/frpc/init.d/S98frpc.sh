#!/bin/sh
sh /jffs/softcenter/scripts/config-frpc.sh
