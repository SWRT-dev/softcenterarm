#!/bin/sh

/jffs/softcenter/ss/socks5/socks5config.sh restart
