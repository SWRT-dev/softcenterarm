#!/bin/sh
sh /koolshare/scripts/config-frps.sh
