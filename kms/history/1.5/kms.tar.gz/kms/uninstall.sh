#!/bin/sh

rm /jffs/softcenter/bin/vlmcsd
rm /jffs/softcenter/res/icon-kms.png
rm /jffs/softcenter/scripts/k3c_kms.sh
rm /jffs/softcenter/webs/Module_kms.asp
