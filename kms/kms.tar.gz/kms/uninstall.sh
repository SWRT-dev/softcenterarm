#!/bin/sh

rm /jffs/softcenter/bin/vlmcsd
rm /jffs/softcenter/res/icon-kms.png
rm /jffs/softcenter/scripts/kms.sh
rm /jffs/softcenter/webs/Module_kms.asp
