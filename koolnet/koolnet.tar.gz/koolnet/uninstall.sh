#!/bin/sh

MODULE=koolnet

rm -f /jffs/softcenter/bin/$MODULE
rm -f /jffs/softcenter/scripts/config-$MODULE.sh
rm -f /jffs/softcenter/webs/Module_$MODULE.asp
rm -f /jffs/softcenter/init.d/S90$MODULE.sh
