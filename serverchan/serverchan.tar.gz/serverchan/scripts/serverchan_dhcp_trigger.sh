#!/bin/sh
source /jffs/softcenter/scripts/base.sh
/jffs/softcenter/serverchan/serverchan_dhcp_trigger
