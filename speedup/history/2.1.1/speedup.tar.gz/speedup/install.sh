#!/bin/sh

cp -r /tmp/speedup/* /jffs/softcenter/
chmod a+x /jffs/softcenter/scripts/speedup*

# add icon into softerware center
dbus set softcenter_module_speedup_install=1
dbus set softcenter_module_speedup_version=2.1.1
dbus set softcenter_module_speedup_description="天翼云盘，为宽带提速而生！！！"

