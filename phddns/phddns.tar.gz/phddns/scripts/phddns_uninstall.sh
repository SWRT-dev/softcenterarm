#!/bin/sh

rm -rf /jffs/softcenter/phddns
rm -rf /jffs/softcenter/init.d/S60Phddns.sh
rm -rf /jffs/softcenter/scripts/phddns_*.sh
rm -rf /jffs/softcenter/webs/Module_phddns.asp
rm -rf /jffs/softcenter/etc/PhMain.ini   
rm -rf /tmp/oray*

exit 0
