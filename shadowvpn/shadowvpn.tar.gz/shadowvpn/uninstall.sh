#!/bin/sh

rm -rf /jffs/configs/dnsmasq.d/ps.conf
rm /jffs/softcenter/scripts/shadowvpn.sh
rm /jffs/softcenter/scripts/shadowvpn_client_up.sh
rm /jffs/softcenter/scripts/shadowvpn_client_down.sh
rm /jffs/softcenter/webs/Module_shadowvpn.asp
rm /jffs/softcenter/bin/shadowvpn
