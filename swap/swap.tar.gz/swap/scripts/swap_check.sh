#! /bin/sh

sh /jffs/softcenter/swap/swap.sh check
