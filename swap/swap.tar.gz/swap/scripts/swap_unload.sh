#! /bin/sh

sh /jffs/softcenter/swap/swap.sh unload
