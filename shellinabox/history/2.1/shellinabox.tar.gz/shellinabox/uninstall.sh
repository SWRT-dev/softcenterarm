#! /bin/sh

killall shellinaboxd
rm -rf /jffs/softcenter/init.d/*shellinabox*
rm -rf /jffs/softcenter/shellinabox
rm -rf /jffs/softcenter/res/icon-shellinabox.png
rm -rf /jffs/softcenter/scripts/shellinabox_start.sh
rm -rf /jffs/softcenter/scripts/uninstall_shellinabox.sh
rm -rf /jffs/softcenter/webs/Module_shellinabox_config.asp
