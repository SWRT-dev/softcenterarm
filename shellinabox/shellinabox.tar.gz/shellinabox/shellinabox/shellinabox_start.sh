#! /bin/sh

#start shellinaboxd
/jffs/softcenter/shellinabox/shellinaboxd --css=/jffs/softcenter/shellinabox/white-on-black.css -b
