#!/bin/sh

rm -rf /jffs/softcenter/bin/ssserver
rm -rf /jffs/softcenter/init.d/jffs/softcenter/init.d/S66ssserver.sh
rm -rf /jffs/softcenter/scripts/ssserve*.sh
rm -rf /jffs/softcenter/webs/Module_ssserver.asp
rm -rf /jffs/softcenter/scripts/uninstall_ssserver.sh
